"use strict";(()=>{var e={};e.id=857,e.ids=[857],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},12393:(e,a,i)=>{i.r(a),i.d(a,{originalPathname:()=>g,patchFetch:()=>v,requestAsyncStorage:()=>p,routeModule:()=>m,serverHooks:()=>u,staticGenerationAsyncStorage:()=>h});var n={};i.r(n),i.d(n,{GET:()=>c});var t=i(49303),r=i(88716),s=i(60670),o=i(58205),d=i(61360);let l={en:{title:"Page not found",description:"The page may have moved or the address may be incorrect.",home:"Back to home",services:d.dz.en.nav.services},id:{title:"Halaman tidak ditemukan",description:"Halaman mungkin sudah dipindah atau alamatnya salah.",home:"Kembali ke beranda",services:d.dz.id.nav.services},zh:{title:"找不到页面",description:"该页面可能已移动，或网址有误。",home:"返回首页",services:d.dz.zh.nav.services}};function c(e,{params:a}){let i=(0,o.jd)(a.lang)?a.lang:"en",{title:n,description:t,home:r,services:s}=l[i],d={home:(0,o.s6)(i),services:`${(0,o.s6)(i)}#services`};return new Response(`<!doctype html>
<html lang="${i}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="robots" content="noindex">
  <title>${n} | PT Lautan Berlian Abadi</title>
  <style>
    body{margin:0;background:#eff4fb;color:#0f172a;font:1rem/1.5 system-ui,sans-serif}
    main{display:grid;min-height:100vh;place-items:center;padding:2rem;box-sizing:border-box}
    div{max-width:32rem;text-align:center}
    h1{margin:.5rem 0;font-size:clamp(2rem,6vw,3rem);line-height:1.15}
    p{margin:0;color:#475569}
    nav{display:flex;flex-wrap:wrap;justify-content:center;gap:.75rem;margin-top:2rem}
    a{border:1px solid #cbd5e1;border-radius:999px;padding:.6rem 1.2rem;color:#0f172a;font-weight:600}
    a:first-child{border-color:#0f172a;background:#0f172a;color:#fff}
  </style>
</head>
<body>
  <main><div>
    <p>404</p>
    <h1>${n}</h1>
    <p>${t}</p>
    <nav><a href="${d.home}">${r}</a><a href="${d.services}">${s}</a></nav>
  </div></main>
</body>
</html>`,{status:404,headers:{"Content-Type":"text/html; charset=utf-8"}})}let m=new t.AppRouteRouteModule({definition:{kind:r.x.APP_ROUTE,page:"/[lang]/[...missing]/route",pathname:"/[lang]/[...missing]",filename:"route",bundlePath:"app/[lang]/[...missing]/route"},resolvedPagePath:"/Applications/MAMP/htdocs/LBA WEB/lba/app/[lang]/[...missing]/route.ts",nextConfigOutput:"standalone",userland:n}),{requestAsyncStorage:p,staticGenerationAsyncStorage:h,serverHooks:u}=m,g="/[lang]/[...missing]/route";function v(){return(0,s.patchFetch)({serverHooks:u,staticGenerationAsyncStorage:h})}},58205:(e,a,i)=>{i.d(a,{B5:()=>r,Nk:()=>c,_O:()=>n,gT:()=>l,jd:()=>o,lE:()=>s,px:()=>t,s6:()=>d});let n="https://www.lbalogistics.id",t="PT Lautan Berlian Abadi",r={url:"/images/about-640.webp",width:1200,height:630,alt:t},s=["en","id","zh"],o=e=>s.includes(e),d=(e,a="")=>"en"===e?a||"/":`/${e}${a}`,l=(e,a="")=>({canonical:`${n}${d(e,a)}`,languages:{en:`${n}${d("en",a)}`,id:`${n}${d("id",a)}`,zh:`${n}${d("zh",a)}`,"x-default":`${n}${d("en",a)}`}}),c={en:{title:"Project Cargo & Freight Forwarding | PT Lautan Berlian Abadi",description:"PT Lautan Berlian Abadi provides project cargo, freight forwarding, customs clearance (PPJK) across Indonesia. Trusted since 2015.",locale:"en_US"},id:{title:"Proyek Kargo & Pengiriman Barang | PT Lautan Berlian Abadi",description:"PT Lautan Berlian Abadi menyediakan layanan proyek kargo, pengiriman barang, kepabeanan (PPJK) ke seluruh Indonesia. Telah dipercaya sejak 2015",locale:"id_ID"},zh:{title:"项目货物及货运代理 | PT Lautan Berlian Abadi",description:"PT Lautan Berlian Abadi 提供覆盖整个印度尼西亚的项目货物运输、货运代理及报关（PPJK）服务。自2015年以来一直深受信赖.",locale:"zh_CN"}}},49303:(e,a,i)=>{e.exports=i(30517)}};var a=require("../../../webpack-runtime.js");a.C(e);var i=e=>a(a.s=e),n=a.X(0,[8948,1360],()=>i(12393));module.exports=n})();